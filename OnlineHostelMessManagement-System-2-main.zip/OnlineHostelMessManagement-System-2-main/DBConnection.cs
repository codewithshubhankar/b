﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShaistaFinalProject
{
    public class DBConnection
    {
        public static string connectionstring = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=ShaistaFinalDB;Integrated Security=True;Pooling=False";
    }
}